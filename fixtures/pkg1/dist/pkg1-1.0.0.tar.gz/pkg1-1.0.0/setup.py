from setuptools import find_packages, setup

setup(
    name='pkg1',
    version='1.0.0',
    description='a package',
    author='Mr Butterfly',
    license='MIT',
    packages=find_packages(),
    zip_safe=False
)
